// Comportamiento común para todas las páginas secundarias
document.addEventListener('DOMContentLoaded', () => {
    console.log('Página cargada - Fantasy F1');
    
    // Efecto hover para botones
    const buttons = document.querySelectorAll('.btn');
    buttons.forEach(btn => {
        btn.addEventListener('mouseenter', () => {
            btn.style.opacity = '0.8';
        });
        btn.addEventListener('mouseleave', () => {
            btn.style.opacity = '1';
        });
    });

    // Notificación al añadir piloto
    const buyButtons = document.querySelectorAll('.driver .btn');
    buyButtons.forEach(btn => {
        btn.addEventListener('click', (e) => {
            e.preventDefault();
            alert('¡Piloto añadido a tu equipo!');
        });
    });
});