// Efectos especiales solo para la página de inicio
document.addEventListener('DOMContentLoaded', () => {
    const hero = document.querySelector('.hero');
    
    // Efecto de paralaje
    window.addEventListener('scroll', () => {
        const scrollValue = window.scrollY;
        hero.style.backgroundPositionY = scrollValue * 0.5 + 'px';
    });

    // Animación de cards
    const cards = document.querySelectorAll('.feature-card');
    cards.forEach((card, index) => {
        setTimeout(() => {
            card.style.opacity = '1';
            card.style.transform = 'translateY(0)';
        }, index * 200);
    });
});